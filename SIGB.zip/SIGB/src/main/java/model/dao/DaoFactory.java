package model.dao;

import database.DB;
import model.dao.impl.*;
public class DaoFactory {

    public static AutorDao createAutorDao() {
        return new AutorDaoJDBC(DB.getConnection());
    }

    public static LivroDao createLivroDao() {
        return new LivroDaoJDBC(DB.getConnection());
    }

    public static CategoriaDaoJDBC createCategoriaDao() {
        return new CategoriaDaoJDBC(DB.getConnection());
    }
}

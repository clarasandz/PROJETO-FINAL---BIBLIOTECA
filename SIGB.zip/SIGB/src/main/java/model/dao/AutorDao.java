package model.dao;

import model.entities.Autor;

import java.util.List;

public interface AutorDao {
    public Autor CriarAutor (Autor autor);
    public boolean AtualizarAutor(Autor autor);
    public boolean ExcluirAutor(Autor autor);
    public List<Autor> AcharTodosAutores ();
    public Autor AcharAutorPorId(Integer id);
}

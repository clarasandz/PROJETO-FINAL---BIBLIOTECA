package model.dao.impl;


import database.DB;
import database.DbException;
import model.dao.LivroDao;
import model.entities.Autor;
import model.entities.Categoria;
import model.entities.Livro;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import static aplication.Program.MenuPrincipal;

public class LivroDaoJDBC implements LivroDao {

    private Connection conn;

    public LivroDaoJDBC(Connection connection) {
        this.conn = connection;

    }

    @Override
    public Livro CriarLivro(Livro livro) {
        String sql1 ="INSERT INTO [Livro](titulo,descricao,qtd) VALUES(?,?,?)";
        String sql2 ="INSERT INTO [Livro_Cat](livroId, CatId) VALUES(?,?)";
        String sql3 ="INSERT INTO [Livro_Autor](idLivro, idAutor) VALUES(?,?)";

        PreparedStatement st1 = null;
        PreparedStatement st2 = null;
        PreparedStatement st3 = null;

        try {
            conn.setAutoCommit(false);

            conn.beginRequest();
            st1 = this.conn.prepareStatement(sql1, Statement.RETURN_GENERATED_KEYS);
            st2 = this.conn.prepareStatement(sql2);
            st3 = this.conn.prepareStatement(sql3);

            st1.setString(1,livro.getTitulo());
            st1.setString(2,livro.getDescricao());
            st1.setInt(3,livro.getQuantidade());

            Integer affectedRows1 = st1.executeUpdate();
            try (ResultSet generatedKeys = st1.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    livro.setId(generatedKeys.getInt(1));
                }
                else {
                    conn.rollback();
                    throw new SQLException("Criação do livro falhou, nenhum ID obtido.");
                }
            }

            st2.setInt(1,livro.getId());
            st2.setInt(2,livro.getCategoria().getId());

            st3.setInt(1,livro.getId());
            st3.setInt(2,livro.getAutor().getId());


            Integer affectedRows2 = st2.executeUpdate();
            Integer affectedRows3 = st3.executeUpdate();

            conn.commit();
            if(affectedRows1 == 0 || affectedRows2==0 ||affectedRows3==0){
                System.out.println("Nenhum registro inserido");
                conn.rollback();
                throw new SQLException("Uma ou mais operações falhou, operações revertidas .");

            }
            else {
                System.out.println("Registro inserido com sucesso");
            }

        } catch (SQLException e) {
            throw new DbException(e.getMessage());
        } finally {
            DB.closeStatement(st1);
            DB.closeStatement(st2);
            DB.closeStatement(st3);

        }
        return livro;
    }

    @Override
    public boolean AtualizarLivro(Livro livro) {
        return false;
    }

    @Override
    public boolean ExcluirLivro(Livro livro) {
        return false;
    }

    @Override
    public List<Livro> AcharTodosLivros() {
        return null;
    }

    @Override
    public Livro AcharLivroPorId(Integer id) {
        return null;
    }

    @Override
    public List<Livro> AcharLivroPorTitulo(String pesquisa) {
        List<Livro> livros = new ArrayList<Livro>();

        String sql ="SELECT [L].id, [L].[qtd], [L].[descricao],[L].titulo, [C].[id] AS [categoriaId], [C].[nome] AS [categoriaNome],\n" +
                "[A].[nome] AS [autorNome], [A].[anoNascimento] AS [autorNasc], [A].[id] AS [autorId]\n" +
                "FROM [Livro] [L]\n" +
                "INNER JOIN [Livro_Cat] LC\n" +
                "ON [LC].[livroId] = L.[id] \n" +
                "INNER JOIN [Categoria] [C]\n" +
                "ON [C].[id] = [LC].[catId] \n" +
                "INNER JOIN [Livro_Autor] [LA]\n" +
                "ON [LC].[livroId] = [L].[id] \n" +
                "INNER JOIN [Autor] [A]\n" +
                "ON [LA].[idAutor] =[A].[id]\n" +
                "WHERE [L].[titulo] LIKE ?";
        PreparedStatement st = null;
        ResultSet rs = null;
        try {
            st = this.conn.prepareStatement(sql);
            st.setString(1, "%"+pesquisa+"%");

            rs = st.executeQuery();
            while (rs.next()) {
                Livro obj = new Livro();
                Categoria categoria = new Categoria(rs.getInt("categoriaId"),rs.getString("categoriaNome"));
                obj.setId(rs.getInt("id"));
                obj.setTitulo(rs.getString("titulo"));
                obj.setDescricao(rs.getString("descricao"));
                obj.setQuantidade(rs.getInt("qtd"));
                obj.setCategoria(categoria);
                Autor autor = new Autor(rs.getInt("autorId"), rs.getString("autorNome"), rs.getInt("autorNasc"));
                obj.setAutor(autor);
                livros.add(obj);
            }
            return livros;
        } catch (SQLException e) {
            throw new DbException(e.getMessage());
        } finally {
            DB.closeStatement(st);
            DB.closeResultSet(rs);
        }
    }

    @Override
    public List<Livro> AcharLivroPorCategoria(Categoria categoria) {
        List<Livro> livros = new ArrayList<Livro>();

        String sql = "SELECT [L].id, [L].[qtd], [L].[descricao],[L].titulo, [C].[id] AS [categoriaId], [C].[nome] AS [categoriaNome],\n" +
                "[A].[nome] AS [autorNome], [A].[anoNascimento] AS [autorNasc], [A].[id] AS [autorId]\n" +
                "FROM [Livro] [L]\n" +
                "INNER JOIN [Livro_Cat] LC\n" +
                "ON [LC].[livroId] = L.[id] \n" +
                "INNER JOIN [Categoria] [C]\n" +
                "ON [C].[id] = [LC].[catId] \n" +
                "INNER JOIN [Livro_Autor] [LA]\n" +
                "ON [LC].[livroId] = [L].[id] \n" +
                "INNER JOIN [Autor] [A]\n" +
                "ON [LA].[idAutor] =[A].[id]\n" +
                "WHERE [C].[id] = ? AND [C].[nome] = ?";
        PreparedStatement st = null;
        ResultSet rs = null;
        try {
            st = this.conn.prepareStatement(sql);
            st.setInt(1, categoria.getId());
            st.setString(2, categoria.getNome());

            rs = st.executeQuery();
            while (rs.next()) {
                Livro obj = new Livro();
                Autor autor = new Autor(rs.getInt("autorId"), rs.getString("autorNome"), rs.getInt("autorNasc"));
                obj.setId(rs.getInt("id"));
                obj.setTitulo(rs.getString("titulo"));
                obj.setDescricao(rs.getString("descricao"));
                obj.setQuantidade(rs.getInt("qtd"));
                obj.setCategoria(categoria);
                obj.setAutor(autor);
                livros.add(obj);
            }
            return livros;
        } catch (SQLException e) {
            throw new DbException(e.getMessage());
        } finally {
            DB.closeStatement(st);
            DB.closeResultSet(rs);
        }
    }
}


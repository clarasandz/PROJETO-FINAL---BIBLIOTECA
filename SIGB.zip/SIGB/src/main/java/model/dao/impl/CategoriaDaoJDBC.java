package model.dao.impl;


import database.DB;
import database.DbException;
import model.dao.CategoriaDao;
import model.entities.Categoria;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import static aplication.Program.MenuPrincipal;

public class CategoriaDaoJDBC implements CategoriaDao {

    private Connection connection;

    public CategoriaDaoJDBC(Connection connection){
        this.connection = connection;
    }


    @Override
    public Categoria CriarCategoria(Categoria categoria) {
        String sql ="INSERT INTO [Categoria]( nome)" +
                "VALUES(?)";
        PreparedStatement st = null;
        ResultSet rs = null;
        try {
            connection.setAutoCommit(false);

            connection.beginRequest();
            st = this.connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            st.setString(1, categoria.getNome());

            Integer affectedRows = st.executeUpdate();
            try (ResultSet generatedKeys = st.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    categoria.setId(generatedKeys.getInt(1));
                }
                else {
                    connection.rollback();
                    throw new SQLException("Creating user failed, no ID obtained.");
                }
            }
            connection.commit();
            if(affectedRows == 0){
                System.out.println("Nenhum registro inserido");
            }
            else {
                System.out.println("Registro inserido com sucesso");
                Scanner scanner = new Scanner(System.in);
                scanner.next();
                MenuPrincipal();
            }

        } catch (SQLException e) {
            throw new DbException(e.getMessage());
        } finally {
            DB.closeStatement(st);
            DB.closeResultSet(rs);
        }
        return null;
    }

    @Override
    public boolean AtualizarCategoria(Categoria categoria) {
        return false;
    }

    @Override
    public boolean ExcluirCategoria(Categoria categoria) {
        return false;
    }

    @Override
    public List<Categoria> AcharTodasCategorias() {

        String sql = "SELECT * FROM Categoria ";
        PreparedStatement st = null;
        ResultSet rs = null;
        List<Categoria> listCategorias = new ArrayList<>();
        try {
            st = this.connection.prepareStatement(sql);
            rs = st.executeQuery();
            while (rs.next()) {
                Categoria obj = new Categoria();
                obj.setId(rs.getInt("Id"));
                obj.setNome(rs.getString("Nome"));
                listCategorias.add(obj);
            }
            return listCategorias;
        }
        catch (SQLException e) {
            throw new DbException(e.getMessage());
        }
        finally {
            DB.closeStatement(st);
            DB.closeResultSet(rs);
        }

    }

    @Override
    public Categoria AcharCategoriaPorId(Integer id) {
        String sql = "SELECT * FROM Categoria WHERE Id = ?";
        PreparedStatement st = null;
        ResultSet rs = null;
        try {
            st = this.connection.prepareStatement(sql);
            st.setInt(1, id);
            rs = st.executeQuery();
            if (rs.next()) {
                Categoria obj = new Categoria();
                obj.setId(rs.getInt("Id"));
                obj.setNome(rs.getString("Nome"));
                return obj;
            }
        }
        catch (SQLException e) {
            throw new DbException(e.getMessage());
        }
        finally {
            DB.closeStatement(st);
            DB.closeResultSet(rs);
        }
        return null;
    }
}

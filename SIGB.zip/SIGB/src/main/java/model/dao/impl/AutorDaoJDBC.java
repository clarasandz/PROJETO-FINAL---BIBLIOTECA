package model.dao.impl;


import database.DB;
import database.DbException;
import model.dao.AutorDao;
import model.entities.Autor;
import model.entities.Categoria;
import model.entities.Livro;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import static aplication.Program.MenuPrincipal;

public class AutorDaoJDBC implements AutorDao {

    private Connection conn;

    public AutorDaoJDBC(Connection connection){
        this.conn = connection;

    }


    @Override
    public Autor CriarAutor(Autor autor) {
        String sql ="INSERT INTO [Autor](anoNascimento, nome)" +
                "VALUES(?,?)";
        PreparedStatement st = null;
        ResultSet rs = null;
        try {
            conn.setAutoCommit(false);

            conn.beginRequest();
            st = this.conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            st.setInt(1, autor.getAnoNascimento());
            st.setString(2, autor.getNome());

            Integer affectedRows = st.executeUpdate();
            try (ResultSet generatedKeys = st.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    autor.setId(generatedKeys.getInt(1));
                }
                else {
                    conn.rollback();
                    throw new SQLException("Creating user failed, no ID obtained.");
                }
            }
            conn.commit();
            if(affectedRows == 0){
                System.out.println("Nenhum registro inserido");
            }
            else {
                System.out.println("Registro inserido com sucesso");
                Scanner scanner = new Scanner(System.in);
                scanner.next();
                MenuPrincipal();
            }

        } catch (SQLException e) {
            throw new DbException(e.getMessage());
        } finally {
            DB.closeStatement(st);
            DB.closeResultSet(rs);
        }
        return null;
    }

    @Override
    public boolean AtualizarAutor(Autor autor) {
        return false;
    }

    @Override
    public boolean ExcluirAutor(Autor autor) {
        return false;
    }

    @Override
    public List<Autor> AcharTodosAutores() {

        String sql = "SELECT * FROM Autor ";
        PreparedStatement st = null;
        ResultSet rs = null;
        List<Autor> autores = new ArrayList<>();
        try {
            st = this.conn.prepareStatement(sql);
            rs = st.executeQuery();
            while (rs.next()) {
                Autor obj = new Autor();
                obj.setId(rs.getInt("Id"));
                obj.setNome(rs.getString("Nome"));
                obj.setAnoNascimento(rs.getInt("anoNascimento"));
                autores.add(obj);
            }
            return autores;
        }
        catch (SQLException e) {
            throw new DbException(e.getMessage());
        }
        finally {
            DB.closeStatement(st);
            DB.closeResultSet(rs);
        }
    }

    @Override
    public Autor AcharAutorPorId(Integer id) {
        String sql = "SELECT * FROM Autor WHERE id = ?";
        PreparedStatement st = null;
        ResultSet rs = null;
        try {
            st = this.conn.prepareStatement(sql);
            st.setInt(1,id);
            rs = st.executeQuery();

            Autor autor = null;
            while (rs.next()) {
                autor = new Autor();
                autor.setId(rs.getInt("Id"));
                autor.setNome(rs.getString("Nome"));
                autor.setAnoNascimento(rs.getInt("anoNascimento"));
            }
            return autor;
        }
        catch (SQLException e) {
            throw new DbException(e.getMessage());
        }
        finally {
            DB.closeStatement(st);
            DB.closeResultSet(rs);
        }
    }
}

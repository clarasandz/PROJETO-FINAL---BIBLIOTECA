package model.dao;




import model.entities.Autor;
import model.entities.Categoria;
import model.entities.Livro;

import java.util.List;

public interface LivroDao {
    public Livro CriarLivro(Livro livro);
    public boolean AtualizarLivro(Livro livro);
    public boolean ExcluirLivro(Livro livro);
    public List<Livro> AcharTodosLivros();
    public Livro AcharLivroPorId(Integer id);
    public List<Livro> AcharLivroPorTitulo(String pesquisa);
    public List<Livro> AcharLivroPorCategoria(Categoria categoria);
}

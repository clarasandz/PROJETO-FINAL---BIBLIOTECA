package model.dao;


import model.entities.Categoria;

import java.sql.Connection;
import java.util.List;

public interface CategoriaDao {
    public Categoria CriarCategoria(Categoria categoria);
    public boolean AtualizarCategoria(Categoria categoria);
    public boolean ExcluirCategoria(Categoria categoria);
    public List<Categoria> AcharTodasCategorias();
    public Categoria AcharCategoriaPorId(Integer id);
}

package model.entities;

public class Livro {
    private Integer id;
    private String titulo;
    private Integer quantidade;
    private Categoria categoria;
    private Autor autor;
    private String descricao;

    public Livro(Integer id, String titulo, Integer quantidade, Categoria categoria, Autor autor, String descricao) {
        this.id = id;
        this.titulo = titulo;
        this.quantidade = quantidade;
        this.categoria = categoria;
        this.autor = autor;
        this.descricao = descricao;
    }

    public Livro(){

    }

    @Override
    public String toString() {
        return "Livro{" +
                "id=" + id +
                ", titulo='" + titulo + '\'' +
                ", quantidade=" + quantidade +
                ", categoria=" + categoria +
                ", autor=" + autor +
                ", descricao='" + descricao + '\'' +
                '}';
    }

    public Integer getId() {
        return id;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public void setId(Integer id) {
        this.id = id;
    }


    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public Integer getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(Integer quantidade) {
        this.quantidade = quantidade;
    }

    public Categoria getCategoria() {
        return categoria;
    }

    public void setCategoria(Categoria categoria) {
        this.categoria = categoria;
    }

    public Autor getAutor() {
        return autor;
    }

    public void setAutor(Autor autor) {
        this.autor = autor;
    }
}

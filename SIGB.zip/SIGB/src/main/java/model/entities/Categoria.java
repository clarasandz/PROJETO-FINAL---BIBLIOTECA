package model.entities;

public class Categoria {
    private Integer Id;
    private String Nome;

    @Override
    public String toString() {
        return "Categoria{" +
                "Id=" + Id +
                ", Nome='" + Nome + '\'' +
                '}';
    }

    public Categoria(){

    }

    public Categoria(Integer id, String nome) {
        Id = id;
        Nome = nome;
    }

    public Integer getId() {
        return Id;
    }

    public void setId(Integer id) {
        Id = id;
    }

    public String getNome() {
        return Nome;
    }

    public void setNome(String nome) {
        Nome = nome;
    }
}

package model.entities;

public class Autor {
    private Integer Id ;
    private String Nome ;
    private Integer AnoNascimento ;

    public Autor(Integer id, String nome, Integer anoNascimento) {
        Id = id;
        Nome = nome;
        AnoNascimento = anoNascimento;
    }
    public Autor(){

    }

    @Override
    public String toString() {
        return "Autor{" +
                "Id=" + Id +
                ", Nome='" + Nome + '\'' +
                ", AnoNascimento=" + AnoNascimento +
                '}';
    }

    public Integer getId() {
        return Id;
    }

    public void setId(Integer id) {
        Id = id;
    }

    public String getNome() {
        return Nome;
    }

    public void setNome(String nome) {
        Nome = nome;
    }

    public Integer getAnoNascimento() {
        return AnoNascimento;
    }

    public void setAnoNascimento(Integer anoNascimento) {
        AnoNascimento = anoNascimento;
    }
}

package aplication.menu.adicionar;

import model.dao.AutorDao;
import model.dao.CategoriaDao;
import model.dao.DaoFactory;
import model.entities.Autor;
import model.entities.Categoria;

import java.util.Scanner;

public class AddCategoria {
    public static void showMenuAddCategoria(){
        Scanner scanner = new Scanner(System.in);

        System.out.println("Insira o nome da categoria");
        String nome = scanner.nextLine();
        Categoria cat = new Categoria(null,nome);

        CategoriaDao categoriaDao =  DaoFactory.createCategoriaDao();
        categoriaDao.CriarCategoria(cat);

    }
}

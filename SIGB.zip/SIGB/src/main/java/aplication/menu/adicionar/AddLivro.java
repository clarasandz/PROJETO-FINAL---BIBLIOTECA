package aplication.menu.adicionar;

import model.dao.AutorDao;
import model.dao.CategoriaDao;
import model.dao.DaoFactory;
import model.dao.LivroDao;
import model.entities.Autor;
import model.entities.Categoria;
import model.entities.Livro;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import static aplication.Program.MenuPrincipal;
import static aplication.util.AutorUtil.ShowAutores;
import static aplication.util.CategoriaUtil.ShowCategorias;
import static aplication.util.menuUtil.isValidOption;

public class AddLivro {
    public static void showMenuAddLivro(){
        Scanner scanner = new Scanner(System.in);

        CategoriaDao categoriaDao = DaoFactory.createCategoriaDao();
        AutorDao autorDao = DaoFactory.createAutorDao();
        if(categoriaDao.AcharTodasCategorias().size()==0 || autorDao.AcharTodosAutores().size()==0){
            System.out.println("Para adicionar um livro é preciso ter ao menos um autor e uma categoria");
            scanner.next();
            MenuPrincipal();
        }


        System.out.println("Insira o titulo do livro");
        String titulo = scanner.nextLine();
        System.out.println("Insira uma descrição");
        String desc = scanner.nextLine();
        System.out.println("Insira a quantidade de livros");
        Integer qtd = scanner.nextInt();

        LivroDao livroDao = DaoFactory.createLivroDao();

        List<Integer> avaliableOptionsCategoria = new ArrayList<>();
        List<Integer> avaliableOptionsAutores = new ArrayList<>();

        Integer categoriaId,AutorId;
        System.out.println("Selecione uma categoria");
        do {
            ShowCategorias(categoriaDao, avaliableOptionsCategoria);
            categoriaId = scanner.nextInt();
        }while (!isValidOption(avaliableOptionsCategoria,categoriaId));

        Categoria categoria = categoriaDao.AcharCategoriaPorId(categoriaId);
        System.out.println("Selecione um autor");
        do {
            ShowAutores(autorDao,avaliableOptionsAutores);
            AutorId = scanner.nextInt();
        }while (!isValidOption(avaliableOptionsAutores,AutorId));

        Autor autor = autorDao.AcharAutorPorId(AutorId);
        System.out.println(autor);
        Livro livro = new Livro(null,titulo,qtd,categoria,autor,desc);

        livroDao.CriarLivro(livro);

        scanner.next();
        MenuPrincipal();
    }
}

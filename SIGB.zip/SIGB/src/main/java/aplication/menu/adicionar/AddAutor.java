package aplication.menu.adicionar;

import model.dao.AutorDao;
import model.dao.DaoFactory;
import model.entities.Autor;

import java.util.Scanner;

public class AddAutor {
    public static void showMenuAddAutor(){
        Scanner scanner = new Scanner(System.in);

        System.out.println("Insira o nome do autor");
        String nome = scanner.nextLine();
        System.out.println("Insira o ano de nascimento do autor");
        Integer anoNasc = scanner.nextInt();
        Autor autor = new Autor(null,nome,anoNasc);

        AutorDao autorDao =  DaoFactory.createAutorDao();
        autorDao.CriarAutor(autor);



    }
}

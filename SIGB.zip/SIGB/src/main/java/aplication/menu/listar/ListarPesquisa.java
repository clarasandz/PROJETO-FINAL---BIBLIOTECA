package aplication.menu.listar;

import model.dao.DaoFactory;
import model.dao.LivroDao;
import model.entities.Livro;

import java.util.List;
import java.util.Scanner;

import static aplication.Program.MenuPrincipal;

public class ListarPesquisa {
    public static void showListarPesquisa(){

        System.out.println("Digite o termo que deseja pesquisar:");
        Scanner scanner = new Scanner(System.in);
        String pesquisa = scanner.nextLine();

        LivroDao livroDao = DaoFactory.createLivroDao();
        List<Livro> livrosPesquisa = livroDao.AcharLivroPorTitulo(pesquisa);
        if(livrosPesquisa.size() ==0 ){
            System.out.println("Nenhum resultados para a busca");
        }
        else {
            System.out.println(livrosPesquisa.size()+ " resultados encontrados");
        }
        for(Livro livro: livrosPesquisa){
            System.out.println("--------------------------------------------------------------------------------------------------------");
            System.out.println(livro.getId() + " - " + livro.getTitulo());
            System.out.println("\tDescrição: " + livro.getDescricao());
            System.out.println("\tQuantidade: " + livro.getQuantidade());
            System.out.println("\tCategoria: " + livro.getCategoria().getNome());
            System.out.println("\tAutor: " + livro.getAutor().getNome());
            System.out.println("--------------------------------------------------------------------------------------------------------\n\n");
        }

        scanner.next();
        MenuPrincipal();
    }
}

package aplication.menu.listar;

import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

import static aplication.menu.listar.ListarPesquisa.showListarPesquisa;
import static aplication.menu.listar.ListarPorCategoriaMenu.showListarPorCategoria;
import static aplication.util.menuUtil.isValidOption;

public class ListarMenu {
    public static void showMenuListar() {
        Integer option;
        List<Integer> avaliableOptions = Arrays.asList(1, 2);

        do {
            System.out.println("1- Listar Livros Por Categoria");
            System.out.println("2- Pesquisar Livros por Nome");
            Scanner scanner = new Scanner(System.in);
            option = scanner.nextInt();

        }while (!isValidOption(avaliableOptions,option));

        switch (option) {
            case 1:
                showListarPorCategoria();
                break;
            case 2:
                showListarPesquisa();
                break;
        }
    }
}

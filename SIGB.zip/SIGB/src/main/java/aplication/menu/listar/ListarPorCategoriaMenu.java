package aplication.menu.listar;

import model.dao.CategoriaDao;
import model.dao.DaoFactory;
import model.dao.LivroDao;
import model.entities.Categoria;
import model.entities.Livro;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

import static aplication.Program.MenuPrincipal;
import static aplication.util.CategoriaUtil.ShowCategorias;
import static aplication.util.menuUtil.isValidOption;

public class ListarPorCategoriaMenu {
    public static void showListarPorCategoria(){
        Integer option;
        List<Integer> avaliableOptions = new ArrayList<>();

        // mostrar categorias
        CategoriaDao categoriaDao = DaoFactory.createCategoriaDao();

        // escolher categoria
        do{
            ShowCategorias(categoriaDao,avaliableOptions);
            Scanner scanner = new Scanner(System.in);
            option = scanner.nextInt();
        }
        while (!isValidOption(avaliableOptions, option));
        // mostrar resultados
        Categoria categoriaChoice = categoriaDao.AcharCategoriaPorId(option);

        LivroDao livroDao= DaoFactory.createLivroDao();
        List<Livro> livrosPesquisa = livroDao.AcharLivroPorCategoria(categoriaChoice);

        if(livrosPesquisa.size()==0){
            System.out.println("Não há livros registrados com essa categoria");
        }

        for(Livro livro: livrosPesquisa){
            System.out.println("--------------------------------------------------------------------------------------------------------");
            System.out.println(livro.getId() + " - " + livro.getTitulo());
            System.out.println("\tDescrição: " + livro.getDescricao());
            System.out.println("\tQuantidade: " + livro.getQuantidade());
            System.out.println("\tCategoria: " + livro.getCategoria().getNome());
            System.out.println("\tAutor: " + livro.getAutor().getNome());
            System.out.println("--------------------------------------------------------------------------------------------------------\n\n");
        }

        Scanner scanner = new Scanner(System.in);
        scanner.next();
        MenuPrincipal();
    }


}

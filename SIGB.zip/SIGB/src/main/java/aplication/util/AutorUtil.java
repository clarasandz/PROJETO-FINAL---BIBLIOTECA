package aplication.util;

import model.dao.AutorDao;
import model.dao.CategoriaDao;
import model.entities.Autor;
import model.entities.Categoria;

import java.util.List;

public class AutorUtil {
    public static void ShowAutores(AutorDao autorDao, List<Integer> avaliableOptions)
    {
        List<Autor> autores = autorDao.AcharTodosAutores();

        for (Autor autor:autores)
        {
            System.out.println(String.format("%d - %s",autor.getId(),autor.getNome()));
            avaliableOptions.add(autor.getId());
        }
    }
}

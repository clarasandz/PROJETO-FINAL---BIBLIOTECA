package aplication.util;

import model.dao.CategoriaDao;
import model.entities.Categoria;

import java.util.List;

public class CategoriaUtil {
    public static void ShowCategorias(CategoriaDao categoriaDao, List<Integer> avaliableOptions)
    {
        List<Categoria> categorias = categoriaDao.AcharTodasCategorias();


        for (Categoria categoria:categorias)
        {
            System.out.println(String.format("%d - %s",categoria.getId(),categoria.getNome()));
            avaliableOptions.add(categoria.getId());
        }
    }
}

package aplication.util;

import java.util.List;

public class menuUtil {
    public static boolean isValidOption(List<Integer> avaliableOptions, Integer option) {
        boolean valid = avaliableOptions.stream().anyMatch(x -> x == option);
        if (!valid) {
            System.out.println("Opção Inválida");
        }
        return valid;
    }
}

package aplication;

import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

import static aplication.menu.adicionar.AddAutor.showMenuAddAutor;
import static aplication.menu.adicionar.AddCategoria.showMenuAddCategoria;
import static aplication.menu.adicionar.AddLivro.showMenuAddLivro;
import static aplication.menu.listar.ListarMenu.showMenuListar;
import static aplication.util.menuUtil.isValidOption;

public class Program {

    public static void main(String[] args) {
        MenuPrincipal();
    }

    public static void MenuPrincipal() {
        Integer option;
        List<Integer> avaliableOptions = Arrays.asList(1, 2, 3, 4);
        do {
            System.out.println(".: Sistema Integrado de Gestão de Biblioteca :.");
            System.out.println("Selecione uma opção:");
            System.out.println("\t1-Adicionar Livro");
            System.out.println("\t2-Adicionar Categoria");
            System.out.println("\t3-Adicionar Autor");

            System.out.println("\t4-Listar Livros");

            System.out.println("\t5-Alugar Livro (Em Breve)");
            System.out.println("\t6-Devolução de Livro(Em Breve)");

            Scanner scanner = new Scanner(System.in);
            option = scanner.nextInt();
        } while (!isValidOption(avaliableOptions, option));

        switch (option) {
            case 1:
                showMenuAddLivro();
                break;
            case 2:
                showMenuAddCategoria();
                break;
            case 3:
                showMenuAddAutor();
                break;
            case 4:
                showMenuListar();
                break;
        }
    }


}
